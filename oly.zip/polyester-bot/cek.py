"""Diagnosa: cek tiap langkah satu per satu (tidak menaruh order sungguhan)."""
import asyncio, os, traceback
from dotenv import load_dotenv
from polyester import AsyncPolyester, POLYESTER_TESTNET_ENVIRONMENT
from polyester.types.money import Price

load_dotenv()


def show_err(e):
    print(f"   GAGAL: {type(e).__name__}: {e}")
    c = e.__cause__
    if c is not None:
        print(f"   penyebab: {type(c).__name__} code={getattr(c, 'code', None)} msg={getattr(c, 'message', c)}")


async def step(name, coro):
    print(f"\n[{name}]")
    try:
        r = await coro
        print("   OK:", str(r)[:600])
    except Exception as e:
        show_err(e)


async def main():
    async with AsyncPolyester(
        environment=POLYESTER_TESTNET_ENVIRONMENT,
        api_key_id=os.environ["POLYESTER_API_KEY_ID"],
        api_private_key=os.environ["POLYESTER_API_PRIVATE_KEY"],
        default_account_id=os.environ["POLYESTER_ACCOUNT_ID"],
        api_url=os.getenv("POLYESTER_API_URL", "https://api.testnet.polyester.com"),
        ws_url=os.getenv("POLYESTER_WS_URL", "wss://api.testnet.polyester.com"),
    ) as c:
        await c.wait_for_catalogs()
        await step("1 saldo", c.balances.list())
        await step("2 order terbuka", c.orders.list_open())
        await step("3 preview market buy 10 USDT", c.orders.preview_order(
            symbol="BTC-USDT", side="buy", order_type="market", tif="ioc", max_quote_debit="10"))
        await step("4 preview market buy qty", c.orders.preview_order(
            symbol="BTC-USDT", side="buy", order_type="market", tif="ioc", qty="0.0001"))
        await step("5 preview market sell qty", c.orders.preview_order(
            symbol="BTC-USDT", side="sell", order_type="market", tif="ioc", qty="0.0001"))
        await step("6 preview limit (harga teks)", c.orders.preview_order(
            symbol="BTC-USDT", side="buy", order_type="limit", tif="gtc", qty="0.0001", price="70000", post_only=True))
        await step("7 preview limit (harga ticks)", c.orders.preview_order(
            symbol="BTC-USDT", side="buy", order_type="limit", tif="gtc", qty="0.0001",
            price=Price(ticks=70000 * 10**9), post_only=True))

asyncio.run(main())
