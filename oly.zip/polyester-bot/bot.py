"""Bot trading otomatis Polyester Testnet (1 akun, via API key)."""
import asyncio, os, random, logging, time
from decimal import Decimal, ROUND_DOWN
from uuid import uuid4
from dotenv import load_dotenv
from polyester import AsyncPolyester, POLYESTER_TESTNET_ENVIRONMENT
from polyester.types.money import Price

load_dotenv()
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    handlers=[logging.FileHandler("bot.log"), logging.StreamHandler()],
)
log = logging.getLogger("polybot")

_PAIRS_RAW = os.getenv("PAIRS", "ALL").strip()
PAIRS = [] if _PAIRS_RAW.upper() == "ALL" else [p.strip() for p in _PAIRS_RAW.split(",") if p.strip()]
ORDER_USDT = Decimal(os.getenv("ORDER_USDT", "10"))
DELAY_MIN = int(os.getenv("DELAY_MIN", "60"))
DELAY_MAX = int(os.getenv("DELAY_MAX", "180"))
QTY_DEC = int(os.getenv("QTY_DECIMALS", "8"))
SELL_RATIO = Decimal(os.getenv("SELL_RATIO", "0.995"))
LIMIT_CHANCE = float(os.getenv("LIMIT_ORDER_CHANCE", "0.3"))

# --- Mode VIP: kejar volume 30 hari biar naik tier ---
VIP_MODE = os.getenv("VIP_MODE", "false").lower() == "true"
VIP_TARGET = Decimal(os.getenv("VIP_TARGET_USD", "100000"))
SKIP = {}  # pair -> waktu boleh dipakai lagi
LAST_SYMBOL = ""
VIP_PAIRS = [p.strip() for p in os.getenv("VIP_PAIRS", "ALL").split(",") if p.strip()]
VIP_ORDER_USDT = Decimal(os.getenv("VIP_ORDER_USDT", "100"))
VIP_DELAY_MIN = int(os.getenv("VIP_DELAY_MIN", "5"))
VIP_DELAY_MAX = int(os.getenv("VIP_DELAY_MAX", "20"))
MAX_FEE_USDT = Decimal(os.getenv("MAX_FEE_USDT", "150"))
# Volume 30 hari saat bot mulai (lihat di Dashboard -> VIP Tier), API key tidak bisa membacanya
VIP_START_VOLUME = Decimal(os.getenv("VIP_START_VOLUME", "0"))
TAKER_FEE = Decimal("0.0015")  # VIP 0 taker

stats = {"volume": Decimal(0), "fee": Decimal(0)}


def cid(prefix: str) -> str:
    return f"{prefix}-{uuid4().hex[:20]}"


def to_dec(v) -> Decimal | None:
    try:
        return Decimal(str(v))
    except Exception:
        return None


# Server mengirim harga dalam "ticks" dengan 9 desimal (80248950000000 = 80248.95)
TICK = Decimal(10) ** 9


async def last_prices(client) -> dict[str, Decimal]:
    overview = await client.market_overview.list(limit=100)
    out = {}
    for m in overview.markets:
        sym = m.symbol or client.catalogs.symbol_for_symbol_id(m.symbol_id)
        p = Decimal(m.last_price.ticks) / TICK if m.last_price is not None else Decimal(0)
        if sym and p > 0:
            out[sym] = p
        elif sym:
            out.setdefault(sym, Decimal(0))
    # Pair tanpa harga terakhir (mis. BTC-USDC baru listing): hitung silang lewat USDT
    for sym, p in list(out.items()):
        if p == 0:
            base, quote = sym.split("-")
            b, q = out.get(f"{base}-USDT"), quote_usdt(out, quote)
            out[sym] = (b / q) if b and q else Decimal(0)
    return {k: v for k, v in out.items() if v > 0}


def quote_usdt(prices: dict, quote: str) -> Decimal | None:
    """Harga 1 unit quote dalam USDT (USDT=1, USDC~1, BTC~80rb)."""
    if quote == "USDT":
        return Decimal(1)
    return prices.get(f"{quote}-USDT") or None


def track(usd: Decimal):
    stats["volume"] += usd
    stats["fee"] += usd * TAKER_FEE


def qdec(n: int) -> Decimal:
    return Decimal(1).scaleb(-n)


async def market_buy(client, symbol: str, qusdt: Decimal, size: Decimal):
    quote = symbol.split("-")[1]
    qscale = client.catalogs.quote_quantity_scale_for_symbol(symbol)
    budget = (size / qusdt).quantize(qdec(qscale), rounding=ROUND_DOWN)
    r = await client.orders.create(
        symbol=symbol, side="buy", order_type="market", tif="ioc",
        max_quote_debit=str(budget), client_order_id=cid("buy"),
    )
    log.info("BUY  %s %s %s (~%s USDT) -> %s", symbol, budget, quote, size, r.status)
    track(size)


async def market_sell(client, symbol: str, price: Decimal, qusdt: Decimal, size: Decimal):
    # jual 97% dari nilai beli: sisa buat fee + selisih harga, biar nggak "Insufficient funds"
    dec = min(QTY_DEC, client.catalogs.base_quantity_scale_for_symbol(symbol))
    q = (size * Decimal("0.97") / (price * qusdt)).quantize(qdec(dec), rounding=ROUND_DOWN)
    if q <= 0:
        log.warning("Qty jual %s terlalu kecil, naikkan QTY_DECIMALS", symbol)
        return
    try:
        r = await client.orders.create(
            symbol=symbol, side="sell", order_type="market", tif="ioc",
            qty=str(q), client_order_id=cid("sell"),
        )
    except Exception as e:
        if "insufficient" in str(e).lower():
            raise
        q = q.quantize(qdec(4), rounding=ROUND_DOWN)  # coba presisi lebih kasar
        log.warning("Jual ditolak (%r), coba ulang qty %s", e, q)
        r = await client.orders.create(
            symbol=symbol, side="sell", order_type="market", tif="ioc",
            qty=str(q), client_order_id=cid("sell"),
        )
    log.info("SELL %s qty %s -> %s", symbol, q, r.status)
    track(q * price * qusdt)


async def limit_place_cancel(client, symbol: str, price: Decimal, qusdt: Decimal):
    # Pasang limit buy 3% di bawah harga (post-only, tidak langsung match), lalu batalkan
    sig = max(2, 6 - len(str(int(price))))  # ~6 digit signifikan
    px = (price * Decimal("0.97")).quantize(qdec(sig if price >= 1 else 8), rounding=ROUND_DOWN)
    dec = min(QTY_DEC, client.catalogs.base_quantity_scale_for_symbol(symbol))
    q = (ORDER_USDT / (px * qusdt)).quantize(qdec(dec), rounding=ROUND_DOWN)
    oid = cid("lim")
    r = await client.orders.create(
        symbol=symbol, side="buy", order_type="limit", tif="gtc",
        price=Price(ticks=int(px * TICK)), qty=str(q), post_only=True, client_order_id=oid,
    )
    log.info("LIMIT %s %s @ %s -> %s", symbol, q, px, r.status)
    await asyncio.sleep(random.randint(10, 40))
    await client.orders.cancel(client_order_id=oid)
    log.info("CANCEL %s", oid)


async def one_round(client, vip: bool):
    prices = await last_prices(client)
    if vip:
        mode = VIP_PAIRS[0].upper() if len(VIP_PAIRS) == 1 else ""
        if mode == "ALL":
            pairs = sorted(prices)
        elif mode in ("USDT", "USDC", "BTC"):
            pairs = sorted(p for p in prices if p.endswith("-" + mode))
        else:
            pairs = VIP_PAIRS
        size, lim = VIP_ORDER_USDT, 0.0
    else:
        pairs, size, lim = (PAIRS or sorted(prices)), ORDER_USDT, LIMIT_CHANCE
    now = time.time()
    ok = [p for p in pairs if SKIP.get(p, 0) < now]
    if not ok:  # semua pair lagi di-skip: pakai pair USDT
        ok = [p for p in pairs if p.endswith("-USDT")] or pairs
    symbol = random.choice(ok)
    global LAST_SYMBOL
    LAST_SYMBOL = symbol
    price = prices.get(symbol)
    qusdt = quote_usdt(prices, symbol.split("-")[1])
    if not price or not qusdt:
        log.warning("Harga %s tidak ditemukan, skip", symbol)
        return
    if random.random() < lim:
        await limit_place_cancel(client, symbol, price, qusdt)
    else:
        # beli dulu, tunggu sebentar, lalu jual kembali biar saldo tetap seimbang
        await market_buy(client, symbol, qusdt, size)
        await asyncio.sleep(random.randint(2, 8) if vip else random.randint(5, 30))
        await market_sell(client, symbol, price, qusdt, size)


async def vip_volume(client) -> Decimal:
    """Coba baca dari akun; kalau API key tidak boleh, pakai perkiraan lokal."""
    try:
        st = await client.vip.get_vip_status()
        v = Decimal(st.settled_volume_30d_usd or "0")
        src = "akun"
    except Exception:
        v = VIP_START_VOLUME + stats["volume"]
        src = "perkiraan"
    log.info("Volume 30 hari (%s): $%s / target $%s", src, f"{v:,.0f}", f"{VIP_TARGET:,.0f}")
    return v


async def main():
    async with AsyncPolyester(
        environment=POLYESTER_TESTNET_ENVIRONMENT,
        api_key_id=os.environ["POLYESTER_API_KEY_ID"],
        api_private_key=os.environ["POLYESTER_API_PRIVATE_KEY"],
        default_account_id=os.environ["POLYESTER_ACCOUNT_ID"],
        api_url=os.getenv("POLYESTER_API_URL", "https://api.testnet.polyester.com"),
        ws_url=os.getenv("POLYESTER_WS_URL", "wss://api.testnet.polyester.com"),
    ) as client:
        await client.wait_for_catalogs()
        log.info("Bot jalan. Pair: %s", ", ".join(PAIRS) if PAIRS else "SEMUA pair")
        vip = VIP_MODE
        if vip:
            log.info("MODE VIP aktif: %s USDT per order di %s, batas fee %s USDT",
                     VIP_ORDER_USDT, ",".join(VIP_PAIRS), MAX_FEE_USDT)
        n = 0
        while True:
            if vip and n % 20 == 0:
                v = await vip_volume(client)
                if v >= VIP_TARGET:
                    log.info("Target volume tercapai! Balik ke mode normal.")
                    vip = False
            if vip and stats["fee"] >= MAX_FEE_USDT:
                log.info("Batas fee %s USDT tercapai, mode VIP berhenti.", MAX_FEE_USDT)
                vip = False
            try:
                await one_round(client, vip)
            except Exception as e:  # jangan sampai bot mati karena 1 error
                c = e.__cause__
                if "insufficient" in f"{e!r} {c!r}".lower() and LAST_SYMBOL:
                    SKIP[LAST_SYMBOL] = time.time() + 1800
                    log.warning("Saldo %s kurang, pair %s di-skip 30 menit",
                                LAST_SYMBOL.split("-")[1], LAST_SYMBOL)
                log.error("Error: %s: %r | penyebab: %s", type(e).__name__, e,
                          f"code={getattr(c, 'code', None)} msg={getattr(c, 'message', c)}" if c else "-")
            n += 1
            total = VIP_START_VOLUME + stats["volume"]
            pct = (total / VIP_TARGET * 100) if VIP_TARGET else Decimal(0)
            log.info("VOLUME | sesi ini: $%s | total 30 hari: ~$%s / $%s (%s%%) | fee sesi: ~$%s",
                     f"{stats['volume']:,.2f}", f"{total:,.0f}", f"{VIP_TARGET:,.0f}",
                     f"{pct:.1f}", f"{stats['fee']:.2f}")
            if vip:
                await asyncio.sleep(random.randint(VIP_DELAY_MIN, VIP_DELAY_MAX))
            else:
                await asyncio.sleep(random.randint(DELAY_MIN, DELAY_MAX))


if __name__ == "__main__":
    asyncio.run(main())
